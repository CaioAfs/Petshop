/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package View;

import DAO.animaisDAO;
import Model.animais;
import javax.swing.table.DefaultTableModel;

public class Animais extends javax.swing.JFrame {

    public Animais() throws Exception {
        initComponents();
         setSize(900, 600);
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        setLocationRelativeTo(null);
        setTitle("Cadastrar Clientes");
        setResizable(false);
        preencherTabela();
    }
    public void preencherTabela() throws Exception{
  DefaultTableModel modelo = (DefaultTableModel) jTAnimais.getModel();
         animaisDAO aDAO = new animaisDAO();     
          for(animais a : aDAO.lerAnimal()){
              modelo.addRow(new Object[]{
                  a.getId(),
                  a.getNome(),
                  a.getRaca(),
                  a.getSexo(),
                  a.getDataNascimento(),
                  a.getTutor()        
              });
                      }
    }
    
        public void preencherTabelaPesquisa(String desc) throws Exception{
  DefaultTableModel modelo = (DefaultTableModel) jTAnimais.getModel();
         animaisDAO aDAO = new animaisDAO();     
          for(animais a : aDAO.lerAnimal2(desc)){
              modelo.addRow(new Object[]{
                  a.getId(),
                  a.getNome(),
                  a.getRaca(),
                  a.getSexo(),
                  a.getDataNascimento(),
                  a.getTutor()        
              });
                      }
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        JTFNome = new javax.swing.JTextField();
        JTFRaca = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        JTFId = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        JTFSexo = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTAnimais = new javax.swing.JTable();
        jBSair = new javax.swing.JButton();
        jTFDataNascimento = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jTTutor = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jTFPesquisar = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);
        getContentPane().add(JTFNome);
        JTFNome.setBounds(20, 50, 110, 22);
        getContentPane().add(JTFRaca);
        JTFRaca.setBounds(20, 110, 110, 22);

        jLabel1.setText("Nome");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(20, 20, 50, 16);

        jLabel2.setText("Raca");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(20, 80, 60, 16);
        getContentPane().add(JTFId);
        JTFId.setBounds(160, 50, 100, 22);

        jLabel3.setText("Id");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(160, 20, 50, 16);

        JTFSexo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JTFSexoActionPerformed(evt);
            }
        });
        getContentPane().add(JTFSexo);
        JTFSexo.setBounds(160, 110, 90, 22);

        jLabel4.setText("Sexo");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(160, 80, 120, 16);

        jTAnimais.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id", "Nome", "Raca", "Sexo", "Data_Nascimento", "Tutor"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTAnimais);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(10, 170, 780, 110);

        jBSair.setText("Sair");
        jBSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBSairActionPerformed(evt);
            }
        });
        getContentPane().add(jBSair);
        jBSair.setBounds(710, 100, 75, 60);
        getContentPane().add(jTFDataNascimento);
        jTFDataNascimento.setBounds(290, 50, 110, 22);

        jLabel5.setText("Data Nascimento");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(290, 20, 110, 16);

        jLabel6.setText("Tutor");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(290, 80, 50, 16);
        getContentPane().add(jTTutor);
        jTTutor.setBounds(290, 110, 110, 22);

        jLabel7.setText("Pesquisar");
        getContentPane().add(jLabel7);
        jLabel7.setBounds(440, 20, 80, 16);
        getContentPane().add(jTFPesquisar);
        jTFPesquisar.setBounds(440, 50, 170, 22);

        jButton1.setText("Pesquisar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(625, 40, 110, 40);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void JTFSexoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JTFSexoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_JTFSexoActionPerformed

    private void jBSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBSairActionPerformed
       this.dispose();
    }//GEN-LAST:event_jBSairActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Animais.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Animais.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Animais.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Animais.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new Animais().setVisible(true);
                } catch (Exception ex) {
                    
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField JTFId;
    private javax.swing.JTextField JTFNome;
    private javax.swing.JTextField JTFRaca;
    private javax.swing.JTextField JTFSexo;
    private javax.swing.JButton jBSair;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTAnimais;
    private javax.swing.JTextField jTFDataNascimento;
    private javax.swing.JTextField jTFPesquisar;
    private javax.swing.JTextField jTTutor;
    // End of variables declaration//GEN-END:variables
}
