/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package petshop;




import View.Login;
import View.Principal;
import java.sql.SQLException;
import java.text.ParseException;
public class PetShop {

    public static void main(String[] args) throws SQLException, ParseException{  
        /*
        clienteDAO d = new clienteDAO();
        clientes c = new clientes();
        c.setNome("Marcelo");
        c.setCpf("123123");
        c.setEmail("m@gmail.com");
        c.setTelefone("4444");
        c.setDataNascimento("2000/01/01");
        c.setEndereco_id("3");
        d.inserirAp(c);
        
        Principal p = new Principal();
        p.setVisible(true);
        */
        //  Principal p = new Principal();
        // p.setVisible(true);
        Login l = new Login();
        l.setVisible(true);
    }
    
}
