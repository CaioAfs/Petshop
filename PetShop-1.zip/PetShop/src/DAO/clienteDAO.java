package DAO;

import Controller.FabricaConexao;
import Model.clientes;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class clienteDAO {
         
public void inserirC(clientes c)
        
{
String sql= "INSERT INTO clientes(nome,cpf,email,telefone,dataNascimento,Enderecos_id)"
             + " VALUES (?,?,?,?,?,?)";
    
   Connection conexao = null;
    PreparedStatement pstmt = null;
      
    try {
        conexao = FabricaConexao.criaConexao();
        pstmt = conexao.prepareStatement(sql);
         pstmt.setString(1,c.getNome());
           pstmt.setString(2,c.getCpf());
              pstmt.setString(3,c.getEmail());
                 pstmt.setString(4,c.getTelefone());
                    pstmt.setString(5,c.getDataNascimento());
                       pstmt.setInt(6,c.getEndereco_id());
         pstmt.execute();
         JOptionPane.showMessageDialog(null,
                 "Dados Gravados com Sucesso!!!");
    } catch (Exception e) {
        e.printStackTrace(); 
    }
}

public void alterarC(clientes c)
{             
 String sql= "UPDATE clientes SET nome=?,cpf=?,email=?,telefone=?,dataNascimento=?,Enderecos_id=? "
         + "WHERE id=?";
    
    Connection conexao = null;
    PreparedStatement pstmt = null;
      
    try {
        conexao = FabricaConexao.criaConexao();
        pstmt = conexao.prepareStatement(sql);
        pstmt.setString(1,c.getNome());
        pstmt.setString(2,c.getCpf());
        pstmt.setString(3,c.getEmail());
        pstmt.setString(4,c.getTelefone());
        pstmt.setString(5,c.getDataNascimento());
        pstmt.setInt(6,c.getEndereco_id());
        pstmt.setInt(7,c.getId());
        pstmt.execute();
    } catch (Exception e) {
        e.printStackTrace(); 
    }
}


public void delete(clientes co)
	{
		String sql = "Delete from clientes where id = ?";
		
 Connection conexao = null;
    
     PreparedStatement stmt = null;
     try {
        conexao = FabricaConexao.criaConexao();
	stmt = conexao.prepareStatement(sql);
        stmt.setInt(1, co.getId());
	stmt.executeUpdate();
		
	} catch (Exception e) {
            System.out.println(e.getMessage());
	}
	}
	
public List<clientes> ler() throws Exception{
 Connection conexao = FabricaConexao.criaConexao();
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    List<clientes> cliente = new ArrayList<>();
    
    try {
        pstmt = conexao.prepareStatement("Select * from clientes");
        rs = pstmt.executeQuery();
        while(rs.next())
        {
        clientes c = new clientes();
        c.setId(rs.getInt("id"));
        c.setNome(rs.getString("nome"));
        c.setCpf(rs.getString("cpf"));
        c.setEmail(rs.getString("email"));
        c.setTelefone(rs.getString("telefone"));
        c.setDataNascimento(rs.getString("dataNascimento"));
        c.setEndereco_id(rs.getInt("Enderecos_id"));
        cliente.add(c);
           System.out.println(c.getNome());
        } 
    } catch (Exception e) {
    }
        return cliente;
}

public List<clientes> ler2(String desc) throws Exception{
 Connection conexao = FabricaConexao.criaConexao();
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    List<clientes> cliente = new ArrayList<>();
    try {
        pstmt = conexao.prepareStatement("Select * from clientes where nome LIKE ?");
        pstmt.setString(1,"%"+desc+"%");
        rs = pstmt.executeQuery();
        while(rs.next()){
        clientes c = new clientes();
        c.setId(rs.getInt("id"));
        c.setNome(rs.getString("nome"));
        c.setCpf(rs.getString("cpf"));
        c.setEmail(rs.getString("email"));
        c.setTelefone(rs.getString("telefone"));
        c.setDataNascimento(rs.getString("dataNascimento"));
        c.setEndereco_id(rs.getInt("Enderecos_id"));
        cliente.add(c);
           System.out.println(c.getNome());
        } 
    } catch (Exception e) {
    }
        return cliente;
}

}