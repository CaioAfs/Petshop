
package DAO;

import Controller.FabricaConexao;
import Model.animais;
import Model.clientes;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import java.util.List;


public class animaisDAO {
   
    public List<animais> lerAnimal() throws Exception{
    Connection conexao = (Connection) FabricaConexao.criaConexao();
    PreparedStatement pstmt = null;
    ResultSet rs= null;  
     List<animais> animal = new ArrayList<>();
        try {
         pstmt = conexao.prepareStatement("SELECT * FROM animais");
         rs = pstmt.executeQuery();
         while(rs.next()){
         animais a = new animais();
         a.setId(rs.getInt("id"));
         a.setNome(rs.getString("nome"));
         a.setRaca(rs.getString("raca"));
         a.setSexo(rs.getString("sexo"));
         a.setDataNascimento(rs.getString("dataNascimento"));
         a.setTutor(rs.getInt("tutor_id"));
         animal.add(a);
             System.out.println(a.getNome());
         }
        } catch (Exception e) {
        }
    return animal;
    }
    
    public List<animais> lerAnimal2(String desc) throws Exception{
    Connection conexao = (Connection) FabricaConexao.criaConexao();
    PreparedStatement pstmt = null;
    ResultSet rs= null;  
     List<animais> animal = new ArrayList<>();
        try {
         pstmt = conexao.prepareStatement("SELECT * FROM animais where nome LIKE ?");
         pstmt.setString(1,"%"+desc+"%");
         rs = pstmt.executeQuery();
         while(rs.next()){
         animais a = new animais();
         a.setId(rs.getInt("id"));
         a.setNome(rs.getString("nome"));
         a.setRaca(rs.getString("raca"));
         a.setSexo(rs.getString("sexo"));
         a.setDataNascimento(rs.getString("dataNascimento"));
         a.setTutor(rs.getInt("tutor_id"));
         animal.add(a);
             System.out.println(a.getNome());
         }
        } catch (Exception e) {
        }
    return animal;
    }    
}


